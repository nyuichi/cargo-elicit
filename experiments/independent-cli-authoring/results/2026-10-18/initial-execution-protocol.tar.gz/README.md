# Fresh adler2 authoring comparison for the independent CLI

This protocol compares the incompatible 0.2 CLI plus its optional skill with ordinary Codex. It does not invoke the removed cargo-elicit agent orchestration.

- Subject: checksummed original crates.io adler2 2.0.1, no initial proof files or old ledgers.
- One fresh Codex thread per arm, sequential treatment then control, inherited model/reasoning settings recorded from the actual server response. One authoring turn per arm, no subagents or proof hints. A natural early return is a result, not a reason to reset the attempt.
- Maximum 10,800 seconds per arm. Installation, upstream tests and readiness checks are preparation. End-to-end authoring includes tool initialization, native verification, status observations and the final author report. A separate investigator audit is timed separately.
- Treatment: read the frozen cargo-elicit SKILL and public CLI documentation; use native tools freely, check when useful, status after meaningful work, and fresh audit for final evidence. No per-lemma task or submission protocol. Control: native tools only, no cargo-elicit.
- Same five API properties and additional laws in TASK.md, original optimized runtime and manifest unchanged. Only standard Lean axioms. No old/public proof solutions or sibling trial access.
- Save source hashes, exact binary identity, resolved model settings, cumulative token counters, command count/duration/exit, compaction/error events, author final text, observed progress and raw product phase telemetry. Missing counters are unavailable. Counts inferred from shell text are lower bounds, not complete native process traces.
- Observer status reads occur at the first accepted API, three accepted APIs, 10 minutes, each subsequent 30-minute checkpoint, and termination. They add no proof hints. Coverage milestones from snapshots are provisional until semantic review and independent audit.
- The worker writes an English self-assessment. The investigator separately checks actual theorem statements, original-body correspondence, successful execution, arbitrary initial states and slices, and transitive axioms. Self-reported completion is not accepted coverage.
- Report common 0–5 independently accepted API coverage, supplementary laws, wall time, tokens, checking/observation overhead, repeated failed commands and interruptions. Preserve failures. Compare this fresh pair primarily; the historical 28.40-minute ordinary trial is context, not a matched new control.
- One pair is exploratory and cannot establish statistical speedup or general robustness. Freeze the product during the trial; do not tune it to this run.

Readiness is currently blocked by Codex CLI authentication (HTTP 401 / refresh token invalid). No timed authoring has started. The blocking state is not a product performance result.
