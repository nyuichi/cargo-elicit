import Tail

set_option pp.fullNames true
#check @AdlerProof.tail_loop
#print axioms AdlerProof.tail_loop
