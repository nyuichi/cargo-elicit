import Vector

set_option pp.fullNames true
#check @AdlerProof.vector_add
#print axioms AdlerProof.vector_add
