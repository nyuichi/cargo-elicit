import Vector

set_option pp.fullNames true
#check @AdlerProof.vector_mul
#print axioms AdlerProof.vector_mul
