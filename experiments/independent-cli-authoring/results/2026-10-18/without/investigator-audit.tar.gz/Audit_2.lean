import Codec

set_option pp.fullNames true
#check @AdlerProof.from_checksum_correct
#print axioms AdlerProof.from_checksum_correct
