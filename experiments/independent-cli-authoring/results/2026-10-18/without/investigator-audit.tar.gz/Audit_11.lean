import Vector

set_option pp.fullNames true
#check @AdlerProof.vector_from
#print axioms AdlerProof.vector_from
