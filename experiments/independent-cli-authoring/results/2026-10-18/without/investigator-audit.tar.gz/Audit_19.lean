import Sums

set_option pp.fullNames true
#check @AdlerProof.sum_loop3
#print axioms AdlerProof.sum_loop3
