import Laws

set_option pp.fullNames true
#check @AdlerProof.codec_state_roundtrip
#print axioms AdlerProof.codec_state_roundtrip
