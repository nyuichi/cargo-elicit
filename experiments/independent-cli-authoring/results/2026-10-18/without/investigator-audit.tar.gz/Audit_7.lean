import Laws

set_option pp.fullNames true
#check @AdlerProof.codec_checksum_roundtrip
#print axioms AdlerProof.codec_checksum_roundtrip
