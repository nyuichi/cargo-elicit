import Sums

set_option pp.fullNames true
#check @AdlerProof.sum_loop
#print axioms AdlerProof.sum_loop
