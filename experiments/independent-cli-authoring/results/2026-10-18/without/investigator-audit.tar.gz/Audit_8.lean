import Laws

set_option pp.fullNames true
#check @AdlerProof.split_update
#print axioms AdlerProof.split_update
