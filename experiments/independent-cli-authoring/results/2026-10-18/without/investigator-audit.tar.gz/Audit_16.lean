import Inner

set_option pp.fullNames true
#check @AdlerProof.final_inner_loop
#print axioms AdlerProof.final_inner_loop
