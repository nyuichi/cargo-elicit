import API

set_option pp.fullNames true
#check @AdlerProof.write_slice_correct
#print axioms AdlerProof.write_slice_correct
