import Outer

set_option pp.fullNames true
#check @AdlerProof.outer_loop
#print axioms AdlerProof.outer_loop
