import API

set_option pp.fullNames true
#check @AdlerProof.adler32_slice_correct
#print axioms AdlerProof.adler32_slice_correct
