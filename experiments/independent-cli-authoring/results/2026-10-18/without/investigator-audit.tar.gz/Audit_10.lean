import Compute

set_option pp.fullNames true
#check @AdlerProof.compute_correct_ring
#print axioms AdlerProof.compute_correct_ring
