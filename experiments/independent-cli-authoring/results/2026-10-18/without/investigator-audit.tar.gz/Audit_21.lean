import Specification

set_option pp.fullNames true
#check @AdlerProof.scalar_append
#print axioms AdlerProof.scalar_append
