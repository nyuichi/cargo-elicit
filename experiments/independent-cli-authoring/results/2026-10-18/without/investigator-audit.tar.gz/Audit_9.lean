import Laws

set_option pp.fullNames true
#check @AdlerProof.save_restore_resume
#print axioms AdlerProof.save_restore_resume
