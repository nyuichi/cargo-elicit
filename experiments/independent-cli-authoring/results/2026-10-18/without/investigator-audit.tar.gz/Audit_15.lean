import Inner

set_option pp.fullNames true
#check @AdlerProof.inner_loop
#print axioms AdlerProof.inner_loop
