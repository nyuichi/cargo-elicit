import API

set_option pp.fullNames true
#check @AdlerProof.write_slice_empty
#print axioms AdlerProof.write_slice_empty
