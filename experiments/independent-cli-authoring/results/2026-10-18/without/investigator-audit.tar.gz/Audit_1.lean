import Codec

set_option pp.fullNames true
#check @AdlerProof.checksum_correct
#print axioms AdlerProof.checksum_correct
