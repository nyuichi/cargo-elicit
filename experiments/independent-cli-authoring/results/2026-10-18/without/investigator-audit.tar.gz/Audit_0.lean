import Codec

set_option pp.fullNames true
#check @AdlerProof.new_correct
#print axioms AdlerProof.new_correct
