import Vector

set_option pp.fullNames true
#check @AdlerProof.vector_rem
#print axioms AdlerProof.vector_rem
