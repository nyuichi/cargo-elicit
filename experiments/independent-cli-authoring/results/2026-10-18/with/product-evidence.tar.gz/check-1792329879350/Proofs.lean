import ElicitContracts
namespace Proofs
open Aeneas Aeneas.Std ElicitGenerated
end Proofs
