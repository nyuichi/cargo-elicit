import Proofs
set_option pp.fullNames true
#check @Proofs.decode_encode
#print axioms Proofs.decode_encode
#check @Proofs.encode_decode
#print axioms Proofs.encode_decode
#check @Proofs.scalar_update_append
#print axioms Proofs.scalar_update_append
#check @Proofs.split_update
#print axioms Proofs.split_update
#check @Proofs.save_restore_resume
#print axioms Proofs.save_restore_resume
#check @Proofs.split_save_restore_resume
#print axioms Proofs.split_save_restore_resume
#check @Proofs.update_eq_normalize_fold
#print axioms Proofs.update_eq_normalize_fold
#check @Proofs.update_cons
#print axioms Proofs.update_cons
#check @Proofs.compute_spec
#print axioms Proofs.compute_spec
