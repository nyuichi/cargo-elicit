from pathlib import Path
import os,subprocess,json,time,re,hashlib
base=Path('/workspace/elicit-independent-authoring-2026-10-18');root=base/'cases/with';out=base/'investigator/with';proofs=root/'elicit-proofs/aeneas'
assert json.loads((out/'timing.json').read_text())['exit']==0
cache=max((root/'.elicit/cache').glob('audit-*'),key=lambda p:p.stat().st_mtime_ns)
roots=['Proofs.decode_encode','Proofs.encode_decode','Proofs.scalar_update_append','Proofs.split_update','Proofs.save_restore_resume','Proofs.split_save_restore_resume','Proofs.update_eq_normalize_fold','Proofs.update_cons','Proofs.compute_spec']
file=out/'AuditSupplementary.lean';file.write_text('import Proofs\nset_option pp.fullNames true\n'+''.join('#check @'+n+'\n#print axioms '+n+'\n' for n in roots))
backend=Path(os.environ['AENEAS_HOME'])/'backends/lean';search=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=backend,text=True).strip();env=os.environ.copy();env['LEAN_PATH']=str(cache)+':'+search;t=time.monotonic()
with (out/'supplementary.log').open('w') as log:r=subprocess.run(['lake','env','lean',str(file)],cwd=backend,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(out/'supplementary.log').read_text();allowed={'propext','Classical.choice','Quot.sound'};audit={}
for name in roots:
 m=re.search(re.escape("'"+name+"'")+r' depends on axioms: \[([^\]]*)\]',text,re.S)
 ax={x.strip() for x in m[1].split(',') if x.strip()} if m else (set() if "'"+name+"' does not depend on any axioms" in text else None)
 audit[name]={'checked':r.returncode==0 and ax is not None and ax<=allowed,'axioms':sorted(ax) if ax is not None else None}
(out/'supplementary-summary.json').write_text(json.dumps({'exit':r.returncode,'elapsed_seconds':time.monotonic()-t,'fresh_audit_workspace':str(cache),'roots':audit},indent=2)+'\n');assert all(v['checked'] for v in audit.values())
print(json.dumps({'supplementary_checked':len(audit),'seconds':time.monotonic()-t}))
