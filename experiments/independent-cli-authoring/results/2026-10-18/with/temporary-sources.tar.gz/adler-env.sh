export PATH=/workspace/toolchain/cargo/bin:/workspace/toolchain/elan/bin:/workspace/toolchain/aeneas-src/bin:/workspace/toolchain/aeneas-src/charon/charon/target/release:$PATH
export CARGO_HOME=/workspace/toolchain/cargo RUSTUP_HOME=/workspace/toolchain/rustup ELAN_HOME=/workspace/toolchain/elan
