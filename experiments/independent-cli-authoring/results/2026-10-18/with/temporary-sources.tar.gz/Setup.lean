import FinishLoops
open Aeneas Aeneas.Std Result ElicitGenerated AdlerMath
namespace Proofs
@[step] theorem chunkSize_spec : algo.Adler32.compute.CHUNK_SIZE ⦃ v => v.val = 22208 ⦄ := by
  unfold algo.Adler32.compute.CHUNK_SIZE
  step*

example (self : Adler32) (bytes : Slice U8) :
    algo.Adler32.compute self bytes ⦃ out =>
      Specs.state out = Specs.update (Specs.state self) bytes.val ⦄ := by
  unfold algo.Adler32.compute
  simp only [lift, bind_ok]
  step as ⟨r4, hr4⟩
  step as ⟨aligned, haligned, halignedb⟩
  step as ⟨front, rem, hp, hr, hpv, hrv⟩
  step as ⟨chunkSize, hchunkSize⟩
  step as ⟨outer, houter⟩
  trace_state
end Proofs
