#!/bin/bash
source /tmp/adler-env.sh
ADLER_ROOT=/workspace/elicit-independent-authoring-2026-10-18/cases/with
export LEAN_PATH=/tmp/adler-lean:$ADLER_ROOT/.elicit/cache/check:$ADLER_ROOT/elicit-proofs/aeneas
cd /workspace/toolchain/aeneas-src/backends/lean
lake env lean "$@"
